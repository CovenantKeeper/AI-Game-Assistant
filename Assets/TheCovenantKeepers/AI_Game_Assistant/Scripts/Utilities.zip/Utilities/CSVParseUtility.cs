using System.Globalization;

namespace TheCovenantKeepers.AI_Game_Assistant
{
    /// <summary>Lightweight helpers used by the data models to safely parse CSV fields.</summary>
    public static class CSVParseUtility
    {
        public static string GetSafe(string[] parts, int index)
        {
            if (parts == null || index < 0 || index >= parts.Length) return string.Empty;
            return parts[index]?.Trim() ?? string.Empty;
        }

        public static int ParseInt(string s)
        {
            if (int.TryParse((s ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v))
                return v;
            return 0;
        }

        public static float ParseFloat(string s)
        {
            if (float.TryParse((s ?? "").Trim(), NumberStyles.Float | NumberStyles.AllowThousands,
                CultureInfo.InvariantCulture, out var v))
                return v;
            return 0f;
        }

        public static bool ParseBool(string s)
        {
            s = (s ?? "").Trim().ToLowerInvariant();
            return s == "true" || s == "1" || s == "yes" || s == "y";
        }
    }
}
