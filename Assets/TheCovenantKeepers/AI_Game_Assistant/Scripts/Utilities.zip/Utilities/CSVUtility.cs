﻿using System.Collections.Generic;
using System.Text;

namespace TheCovenantKeepers.AI_Game_Assistant
{
    /// <summary>CSV helpers (quote-aware splitting).</summary>
    public static class CSVUtility
    {
        public static IEnumerable<string> SplitCsvLine(string line)
        {
            if (string.IsNullOrEmpty(line))
            {
                yield break;
            }

            var sb = new StringBuilder(line.Length);
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (c == '"')
                {
                    // Handle doubled quotes ("") inside a quoted field
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        sb.Append('"');
                        i++; // skip the escaped quote
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    yield return sb.ToString().Trim();
                    sb.Length = 0;
                }
                else
                {
                    sb.Append(c);
                }
            }

            // last field
            yield return sb.ToString().Trim();
        }
    }
}
