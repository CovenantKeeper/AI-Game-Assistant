﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using TheCovenantKeepers.AI_Game_Assistant;

public static class CSVSaveUtility
{
    public static void SaveCSV(string path, List<string[]> rows, string[] header)
    {
        if (rows == null || rows.Count == 0)
        {
            Debug.LogWarning("No data to export to CSV.");
            return;
        }

        try
        {
            List<string> lines = new List<string>();
            lines.Add(string.Join(",", header));

            foreach (var row in rows)
            {
                List<string> escaped = new List<string>();
                foreach (var field in row)
                {
                    escaped.Add(Escape(field));
                }
                lines.Add(string.Join(",", escaped));
            }

            File.WriteAllLines(path, lines);
            Debug.Log($"✅ CSV saved to: {path}");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"❌ CSV save failed: {ex.Message}");
        }
    }

    public static string Escape(string input)
    {
        if (string.IsNullOrEmpty(input)) return "";
        if (input.Contains(",") || input.Contains("\"") || input.Contains("\n"))
        {
            return $"\"{input.Replace("\"", "\"\"")}\"";
        }
        return input;
    }

}

